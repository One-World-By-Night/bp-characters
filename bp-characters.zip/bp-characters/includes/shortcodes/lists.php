<?php

/** File: includes/render/lists.php
 * Text Domain: bp-characters
 * version 2.0.0
 * @author greghacke
 * Function: render lists functionality for the plugin
 */

defined('ABSPATH') || exit;
