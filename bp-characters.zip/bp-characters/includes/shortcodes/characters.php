<?php

/** File: includes/shortcode/characters.php
 * Text Domain: bp-characters
 * version 2.0.0
 * @author greghacke
 * Function: render characters functionality for the plugin
 */

defined('ABSPATH') || exit;
