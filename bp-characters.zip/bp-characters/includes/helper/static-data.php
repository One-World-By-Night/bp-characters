<?php

/** File: includes/helper/static-data.php
 * Text Domain: bp-characters
 * version 2.0.0
 * @author greghacke
 * Function: static data functionality for the plugin
 */

defined('ABSPATH') || exit;
