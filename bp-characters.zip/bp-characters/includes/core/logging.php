<?php

/** File: includes/core/logging.php
 * Text Domain: bp-characters
 * version 2.0.0
 * @author greghacke
 * Function: logging functionality for the plugin
 */

defined('ABSPATH') || exit;
