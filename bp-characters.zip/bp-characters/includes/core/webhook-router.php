<?php

/** File: includes/core/webhook-router.php
 * Text Domain: bp-characters
 * version 2.0.0
 * @author greghacke
 * Function: webhook router functionality for the plugin
 */

defined('ABSPATH') || exit;
